// 3-bar menu (guides / About / Contact / Donate) + Donate screen: links maujood, UPI / WhatsApp link sahi, back button, offline shell
const assert = require('assert'); const fs = require('fs'); const path = require('path');
const { read, between } = require('./helpers/extract');
const html = read('index.html'), sw = read('sw.js'), contact = read('contact.html');
const ROOT = path.join(__dirname, '..');
let n = 0; const t = (name, fn) => { try { fn(); n++; console.log('✓', name); } catch (e) { console.log('✗', name, '\n  ', e.stack); process.exitCode = 1; } };

const drawer = between(html, '<aside class="es-drawer"', '</aside>');
const links = [...drawer.matchAll(/href="(\/[a-z0-9-]+\.html)" onclick="return drawerOpen\('([^']+)'/g)].map(m => ({ href: m[1], arg: m[2] }));

t('3-bar button topbar me hai (aria-label, aria-expanded) aur chhoti screen ka 📚-rule class par hai', () => {
  assert.ok(/<button class="tb-menu" id="tbMenu"[^>]*onclick="openDrawer\(\)"[^>]*aria-label="[^"]+"[^>]*aria-expanded="false"/.test(html));
  assert.ok(html.includes('<span class="tb-logo"') && html.includes('.tb-left>.tb-logo{display:none;}') && !html.includes('.tb-left>span:first-child'));
});
t('menu me 8 guides + About + Contact; har link ki file repo me hai aur href == drawerOpen url', () => {
  const need = ['cbse-class-10', 'cbse-class-12', 'bser-class-10', 'bser-class-12', 'ssc-cgl', 'ssc-chsl', 'reet-bstc', 'study-tips', 'about', 'contact'];
  for (const k of need) assert.ok(links.some(l => l.href === '/' + k + '.html'), k + ' menu me nahi');
  for (const l of links) { assert.strictEqual(l.href, l.arg, 'href aur drawerOpen alag: ' + l.href); assert.ok(fs.existsSync(path.join(ROOT, l.href.slice(1))), l.href + ' file nahi'); }
});
t('Donate screen: sirf ek hi UPI QR image, repo me valid PNG', () => {
  assert.ok(html.includes('src="/donate-qr.png"') && html.includes('id="donateOverlay"') && html.includes('onclick="drawerDonate()"'));
  const b = fs.readFileSync(path.join(ROOT, 'donate-qr.png')); assert.strictEqual(b.slice(1, 4).toString(), 'PNG'); assert.ok(b.length > 2000 && b.length < 400000);
});
t('UPI link: pa/pn/cu/am sahi; bekaar amount par am nahi judta', () => {
  const src = between(html, 'var ES_DONATE = {', 'function _esMobile()');
  const E = new Function(src + '; return {ES_DONATE, esUpiUrl, esWaUrl};')();
  const u = new URL(E.esUpiUrl(51).replace('upi://', 'https://x/'));
  assert.strictEqual(u.searchParams.get('pa'), E.ES_DONATE.upi.pa); assert.strictEqual(u.searchParams.get('pn'), 'BHUPESH KUMAR');
  assert.strictEqual(u.searchParams.get('cu'), 'INR'); assert.strictEqual(u.searchParams.get('am'), '51.00');
  for (const bad of [0, -5, NaN, 'abc', 100001, undefined, null]) assert.ok(!/[?&]am=/.test(E.esUpiUrl(bad)), 'am nahi judna chahiye: ' + bad);
  assert.ok(E.esUpiUrl(11).startsWith('upi://pay?pa=') && E.esUpiUrl(11).endsWith('&am=11.00'));
});
t('WhatsApp: number contact.html wala hi; har kind ka message pehle se likha; anjaan kind "other" par girta hai', () => {
  const src = between(html, 'var ES_DONATE = {', 'function _esMobile()');
  const E = new Function(src + '; return {ES_DONATE, esWaUrl};')();
  assert.ok(contact.includes('wa.me/' + E.ES_DONATE.wa), 'contact.html aur ES_DONATE ka WhatsApp number alag');
  for (const k of ['thanks', 'pyq', 'paper', 'test', 'other']) {
    const u = E.esWaUrl(k); assert.ok(u.startsWith('https://wa.me/' + E.ES_DONATE.wa + '?text='), k);
    assert.strictEqual(decodeURIComponent(u.split('?text=')[1]), E.ES_DONATE.msgs[k]);
  }
  assert.strictEqual(E.esWaUrl('???'), E.esWaUrl('other'));
  assert.ok(/PYQ/.test(E.ES_DONATE.msgs.pyq) && /Test/.test(E.ES_DONATE.msgs.test) && /Paper/.test(E.ES_DONATE.msgs.paper));
  const kinds = [...html.matchAll(/data-wa="([a-z]+)"/g)].map(m => m[1]); assert.ok(kinds.length >= 5);
  for (const k of kinds) assert.ok(E.ES_DONATE.msgs[k], 'data-wa="' + k + '" ka message nahi');
});
t('Back button: Donate/drawer legal overlay ke baad, baaki sab se pehle band hote hain; isAppBusy bhi jaanta hai', () => {
  const pb = between(html, 'function performBack(){', "const offerP = document.getElementById('offerPopup');");
  assert.ok(pb.indexOf('closeLegal()') < pb.indexOf('closeDonate()') && pb.indexOf('closeDonate()') < pb.indexOf('closeDrawer()'));
  assert.ok(html.includes('isDonateOpen() || isDrawerOpen()) return true;'));
});
t('Offline: QR service-worker shell me, aur CACHE_NAME badla (v21.6 se aage)', () => {
  assert.ok(/APP_SHELL = \[[^\]]*"\/donate-qr\.png"/.test(sw));
  assert.ok(!sw.includes('eduspark-v21.6"'));
});
t('Safety notes maujood: UPI PIN/OTP, 18 se kam par parents, optional, copyright', () => {
  const dn = between(html, 'id="donateOverlay"', '<!-- GOOGLE SIGN-IN SHEET');
  for (const w of ['UPI PIN', 'OTP', '18 साल', 'optional', 'अनुमति']) assert.ok(dn.includes(w), w);
});
console.log(n + ' donate-menu tests passed');
